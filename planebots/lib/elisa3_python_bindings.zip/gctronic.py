
import os
import ctypes
#import vision
import logging
import sys
import time
# Load DLL into memory.
logger = logging.getLogger(__name__)

# # give location of dll


# defines a wrapper class to the Elisa3 robots:
class Elisa3Comm(object):
    if sys.platform == 'win32':
        # Compile the elisa3 dll for your platform with static linkage, so all functions can be found.
        # dllpath = os.path.join("D:\\data\\thesis\elisa3\Elisa-3 demo\pc-side-elisa3-library\\bin\Release","libpc-side-elisa3-library.dll")
        libpath = os.path.join("libpc-side-elisa3-library.dll")
        library = ctypes.cdll.LoadLibrary(libpath)
    else:
# Install libusb drivers:
# cd sudo apt-get install libusb-1.0-0-dev
# Compile with libusb included:
# gcc -c ../usb-comm.c -lusb ../elisa3-lib.c -lusb -fPIC
# Compile a static library .a file
# bundle .o file to a dynamically linked file for use in python
# gcc -shared elisa3-lib.o -lusb-1.0 usb-comm.o -lusb-1.0 -o elisa3.so
# Copy elisa3.so to this directory
# To avoid needing root priviledge:
# -list devices with lsusb: Bus 001 Device 006: ID 1915:0101 Nordic Semiconductor ASA 
# Add rule to	/etc/udev/rules.d to avoid root elevation
# I.e. touch /etc/udev/rules.d 50-elisa3.rules
# SUBSYSTEM=="usb", ATTRS{idVendor}=="1915", ATTR{idProduct}=="0101", MODE="0666"
# Re-login	
	
        libpath = os.path.join("./","elisa3.so")
        #libpath = os.path.join("./","lib")
        library = ctypes.cdll.LoadLibrary(libpath)
        # raise NotImplementedError
    def __init__(self,AddressList = [3655,3658,3533]):
        self.nRobots = len(AddressList)
        self.AddressList = AddressList
        self.cList = x = (ctypes.c_int32*self.nRobots)()
        for i in range(len(AddressList)):
            self.cList[i] = AddressList[i]
        self.AddrPt = ctypes.cast(self.cList, ctypes.POINTER(ctypes.c_int64))

        self.add_functions()
        try:
            logger.info("Starting communications with Elisa3 Dongle")
            self.library.startCommunication(self.AddrPt,self.nRobots)
            for i in range(self.nRobots):
                logger.info(f"Address:{AddressList[i]} Id:{self.getIdFromAddress(AddressList[i])}")

        except OSError as e:
            logger.error(e)
            logger.error("Is the dongle connected? Exiting..")
            exit()
    def add_functions(self):
        # Functions working with implicit type conversion:
        self.computeVerticalAngle =  self.library.computeVerticalAngle
        self.getIdFromAddress =  self.library.getIdFromAddress
        self.setLeftSpeed =  self.library.setLeftSpeed
        self.setRightSpeed =  self.library.setRightSpeed
        self.setBlue =  self.library.setBlue
        self.setRed =  self.library.setRed
        self.setGreen =  self.library.setGreen
        self.getBatteryAdc = self.library.getBatteryPercent
        # unsigned char waitForUpdate(int robotAddr, unsigned long us);
        self.waitForUpdate = self.library.waitForUpdate
    def close(self):
        commrv = self.library.stopCommunication()

if __name__ == '__main__':

    logger.addHandler(logging.StreamHandler())
    logger.setLevel(logging.DEBUG)
    logger.info(f"VerticalAngle test:{Elisa3Comm.library.computeVerticalAngle(10,10)}")
    Comm = Elisa3Comm()
    l=5
    r=-5
    try:

        for ci in range(Comm.nRobots):
            for i in range(Comm.nRobots):
                Address = Comm.AddressList[i]
                try:
                    if i == ci:
                        # Set the blue LED intensity to the level of the right trigger:
                        # intensity = int(gamepad_states["ABS_RZ"]*100/255)
                        Comm.setLeftSpeed(Address,l)
                        Comm.setRightSpeed(Address,r)
                        Comm.setBlue(Address,255)
                        Comm.setRed(Address,1)
                    else:
                        Comm.setLeftSpeed(Address,0)
                        Comm.setRightSpeed(Address,0)
                        Comm.setBlue(Address,0)
                        Comm.setRed(Address,0)
                        # Show the communication is live:
                        Comm.setGreen(Address,1)
                except Exception as e:
                    logger.error(e)

            time.sleep(1)

        for i in range(Comm.nRobots):

            Comm.setLeftSpeed(Comm.AddressList[i],0)
            Comm.setRightSpeed(Comm.AddressList[i],0)
        #     Sleep in order to open the connection long enough to ensure the new settings arrived
        # time.sleep(0.1)
        rv = Comm.waitForUpdate(Comm.AddressList[i],1000)
        logger.info(f"rv:{rv}")
        # Comm.close()
    except (KeyboardInterrupt,SystemExit) as e:
        pass
    #     for i in range(Comm.nRobots):
    #         Comm.setLeftSpeed(Comm.AddressList[i],0)
    #         Comm.setRightSpeed(Comm.AddressList[i],0)
    #         # #ensure packet delivery
    #         #rv = Comm.waitForUpdate(Comm.AddressList[i],10E6)

    #         #     Sleep in order to open the connection long enough to ensure the new settings arrived
    #         time.sleep(0.1)
    #     Comm.close()
